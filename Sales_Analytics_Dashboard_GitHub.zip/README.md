# Sales Analytics Dashboard 📊

An interactive sales analytics dashboard built with **Python, Pandas and Streamlit**.

## Features
- Total sales, orders, units sold and average order value
- City and product filters
- Product-wise and city-wise sales analysis
- Monthly sales trend
- Top-performing product table

## Tech Stack
Python • Pandas • Streamlit • CSV

## Run Locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Project Structure
```text
Sales_Analytics_Dashboard/
├── app.py
├── sales_data.csv
├── requirements.txt
└── README.md
```

## Learning Outcomes
- Working with CSV data using Pandas
- Grouping and aggregating business data
- Creating KPIs and interactive filters
- Building a simple data dashboard

## Author
Himanshu Pal Suryavanshi

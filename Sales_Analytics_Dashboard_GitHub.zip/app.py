import streamlit as st
import pandas as pd

st.set_page_config(page_title="Sales Analytics Dashboard", page_icon="📊", layout="wide")

@st.cache_data
def load_data():
    df = pd.read_csv("sales_data.csv")
    df["Date"] = pd.to_datetime(df["Date"])
    return df

df = load_data()

st.title("📊 Sales Analytics Dashboard")
st.caption("Interactive sales analysis using Python, Pandas and Streamlit")

st.sidebar.header("Filters")
cities = st.sidebar.multiselect("City", sorted(df["City"].unique()), default=sorted(df["City"].unique()))
products = st.sidebar.multiselect("Product", sorted(df["Product"].unique()), default=sorted(df["Product"].unique()))

filtered = df[df["City"].isin(cities) & df["Product"].isin(products)]

if filtered.empty:
    st.warning("No records match the selected filters.")
    st.stop()

total_sales = filtered["Sales"].sum()
orders = len(filtered)
units = filtered["Quantity"].sum()
avg_order = total_sales / orders

c1, c2, c3, c4 = st.columns(4)
c1.metric("Total Sales", f"₹{total_sales:,.0f}")
c2.metric("Orders", f"{orders:,}")
c3.metric("Units Sold", f"{units:,}")
c4.metric("Avg. Order Value", f"₹{avg_order:,.0f}")

st.divider()

left, right = st.columns(2)
with left:
    st.subheader("Sales by Product")
    st.bar_chart(filtered.groupby("Product")["Sales"].sum().sort_values(ascending=False))
with right:
    st.subheader("Sales by City")
    st.bar_chart(filtered.groupby("City")["Sales"].sum().sort_values(ascending=False))

st.subheader("Monthly Sales Trend")
monthly = filtered.set_index("Date").resample("ME")["Sales"].sum()
st.line_chart(monthly)

st.subheader("Top Performing Products")
top = filtered.groupby("Product").agg(
    Total_Sales=("Sales","sum"),
    Units_Sold=("Quantity","sum"),
    Orders=("Product","size")
).sort_values("Total_Sales", ascending=False)
st.dataframe(top, use_container_width=True)

st.caption("Portfolio project for learning and demonstration.")
